import great_expectations as ge
import json
from pathlib import Path
from Entities.batches import Batch
from Entities.datasources import DataSource
from Entities.expectationUtiles import ExpectationUtil
from Entities.expectationsuites import ExpectationSuite
from Entities.databases import DataBaseType

# ----- Config ----
USERNAME = "root"
PASSWORD = ""
HOST = "127.0.0.1"
PORT = "3306"
SCHEMA = "world"

# Get Context
context = ge.get_context()

if __name__ == '__main__':

	#1) Define Data Source Code    
    ds = DataSource(
        username=USERNAME,
        password=PASSWORD,
        ipAddress=HOST,
        port=PORT,
        dataSchema=SCHEMA,
        dataBaseType=DataBaseType.MySQL,
    )
    gx_ds = ds.register_sql_datasource(context=context, name="MySqlDB-DataSource")

    condition =""
    list_of_expectation_configuration=[]
    
    ##########################################################################################
	# Table Name
    TABLE='city'
#---------------------------------        
    # List of expectations for each column
    
	#Expectations For Column [ID]
    expectation_configuration = ExpectationUtil.expect_column_values_to_be_unique("ID")
    list_of_expectation_configuration.append(expectation_configuration)

	#Expectations For Column [District]
    expectation_configuration = ExpectationUtil.expect_column_values_to_not_be_null("District")
    list_of_expectation_configuration.append(expectation_configuration)

	#Expectations For Column [Name]
    expectation_configuration = ExpectationUtil.expect_column_values_to_not_be_null("Name")
    list_of_expectation_configuration.append(expectation_configuration)

    
    # 2) Suite (in-memory)
    suite = ExpectationSuite.create_expectation_suite(
        suite_name=TABLE,
        context=context,
        suite_expectations_list=list_of_expectation_configuration,
    )

    # 3) Batch request
    batch_request = Batch.get_batch(
        datasource=gx_ds,
        schema_name=ds.dataSchema,
        table_name=TABLE,
        condition="",
    )

    # 4) Validate
    print(f"Running validation on table '{TABLE}'...")
    validator = context.get_validator(
        batch_request=batch_request,
        expectation_suite=suite,
    )
    result = validator.validate()

    print("\nValidation finished.")
    print("Success:", result.success)
    if hasattr(result, "statistics"):
        print("Statistics:", result.statistics)
    
     # ------------------------------------------------------------------
    # 6) Export results to JSON
    # ------------------------------------------------------------------
    reports_dir = Path("reports")
    reports_dir.mkdir(exist_ok=True)

    json_path = reports_dir / f"{TABLE}_validation.json"

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(result.to_json_dict(), f, indent=2)

    print(f"\nJSON report saved to: {json_path.resolve()}")
