from great_expectations import ExpectationSuite as GXExpectationSuite

class ExpectationSuite:
    @staticmethod
    def create_expectation_suite(suite_name, context, suite_expectations_list):
        """
        Create an in-memory ExpectationSuite from a list of
        ExpectationConfiguration objects.

        GE 1.x ExpectationSuite signature (simplified):

            ExpectationSuite(
                name: Optional[str] = None,
                expectations: Optional[Sequence[Union[dict,
                    ExpectationConfiguration, Expectation]]] = None,
                ...
            )

        We just pass:
          - name  -> suite_name
          - expectations -> list_of_expectation_configuration
        and do NOT try to save it inside the context here.
        """
        suite = GXExpectationSuite(
            name=str(suite_name),
            expectations=list(suite_expectations_list),
        )
        return suite
