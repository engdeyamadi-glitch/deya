from great_expectations.expectations.expectation_configuration import ExpectationConfiguration

class ExpectationUtil:
    """
    Utility factory for Great Expectations ExpectationConfiguration objects.

    Each static method creates and returns an ExpectationConfiguration
    with the appropriate expectation_type and kwargs.
    """

    @staticmethod
    def _build(expectation_type: str, **kwargs) -> ExpectationConfiguration:
        """
        Internal helper to build an ExpectationConfiguration.

        GE 1.x signature:
            ExpectationConfiguration(expectation_type: str, kwargs: dict, meta: dict = None, ...)
        We pass expectation_type and kwargs as positional args.
        """
        return ExpectationConfiguration(
            expectation_type,
            kwargs,
        )

    # ========= Null / type / set / between =========

    @staticmethod
    def expect_column_values_to_not_be_null(column):
        return ExpectationUtil._build(
            "expect_column_values_to_not_be_null",
            column=column,
        )

    @staticmethod
    def expect_column_values_to_be_null(column):
        return ExpectationUtil._build(
            "expect_column_values_to_be_null",
            column=column,
        )

    @staticmethod
    def expect_column_values_to_be_of_type(column, dataType):
        return ExpectationUtil._build(
            "expect_column_values_to_be_of_type",
            column=column,
            type_=dataType,
        )

    @staticmethod
    def expect_column_values_to_be_in_type_list(column, type_list):
        return ExpectationUtil._build(
            "expect_column_values_to_be_in_type_list",
            column=column,
            type_list=type_list,
        )

    @staticmethod
    def expect_column_values_to_be_in_set(column, valueSet):
        return ExpectationUtil._build(
            "expect_column_values_to_be_in_set",
            column=column,
            value_set=valueSet,
        )

    @staticmethod
    def expect_column_values_to_not_be_in_set(column, valueSet):
        return ExpectationUtil._build(
            "expect_column_values_to_not_be_in_set",
            column=column,
            value_set=valueSet,
        )

    @staticmethod
    def expect_column_values_to_be_between(column, maxValue, minValue):
        """
        Signature kept as (column, maxValue, minValue) to match your original code,
        mapped to GE kwargs: min_value, max_value.
        """
        return ExpectationUtil._build(
            "expect_column_values_to_be_between",
            column=column,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_values_to_be_increasing(column):
        return ExpectationUtil._build(
            "expect_column_values_to_be_increasing",
            column=column,
        )

    @staticmethod
    def expect_column_values_to_be_decreasing(column):
        return ExpectationUtil._build(
            "expect_column_values_to_be_decreasing",
            column=column,
        )

    # ========= Distinct / distribution / aggregates =========

    @staticmethod
    def expect_column_distinct_values_to_equal_set(column, value_set):
        return ExpectationUtil._build(
            "expect_column_distinct_values_to_equal_set",
            column=column,
            value_set=value_set,
        )

    @staticmethod
    def expect_column_distinct_values_to_contain_set(column, value_set):
        return ExpectationUtil._build(
            "expect_column_distinct_values_to_contain_set",
            column=column,
            value_set=value_set,
        )

    @staticmethod
    def expect_column_mean_to_be_between(column, maxValue, minValue):
        return ExpectationUtil._build(
            "expect_column_mean_to_be_between",
            column=column,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_median_to_be_between(column, maxValue, minValue):
        return ExpectationUtil._build(
            "expect_column_median_to_be_between",
            column=column,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_unique_value_count_to_be_between(column, maxValue, minValue):
        return ExpectationUtil._build(
            "expect_column_unique_value_count_to_be_between",
            column=column,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_most_common_value_to_be_in_set(column, value_set):
        return ExpectationUtil._build(
            "expect_column_most_common_value_to_be_in_set",
            column=column,
            value_set=value_set,
        )

    @staticmethod
    def expect_column_sum_to_be_between(column, result_format, minValue, maxValue):
        return ExpectationUtil._build(
            "expect_column_sum_to_be_between",
            column=column,
            result_format=result_format,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_min_to_be_between(column, result_format, minValue, maxValue):
        return ExpectationUtil._build(
            "expect_column_min_to_be_between",
            column=column,
            result_format=result_format,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_max_to_be_between(column, result_format, minValue, maxValue):
        return ExpectationUtil._build(
            "expect_column_max_to_be_between",
            column=column,
            result_format=result_format,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_proportion_of_unique_values_to_be_between(column, minValue, maxValue):
        return ExpectationUtil._build(
            "expect_column_proportion_of_unique_values_to_be_between",
            column=column,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_values_to_be_unique(column):
        return ExpectationUtil._build(
            "expect_column_values_to_be_unique",
            column=column,
        )

    # ========= Length-based expectations =========

    @staticmethod
    def expect_column_value_lengths_to_be_between(column, minValue, maxValue):
        return ExpectationUtil._build(
            "expect_column_value_lengths_to_be_between",
            column=column,
            min_value=minValue,
            max_value=maxValue,
        )

    @staticmethod
    def expect_column_value_lengths_to_equal(column, value):
        return ExpectationUtil._build(
            "expect_column_value_lengths_to_equal",
            column=column,
            value=value,
        )

    # ========= Regex / pattern expectations =========

    @staticmethod
    def expect_column_values_to_match_regex(column, regex):
        return ExpectationUtil._build(
            "expect_column_values_to_match_regex",
            column=column,
            regex=regex,
        )

    @staticmethod
    def expect_column_values_to_match_regex_list(column, regex_list):
        return ExpectationUtil._build(
            "expect_column_values_to_match_regex_list",
            column=column,
            regex_list=regex_list,
        )

    @staticmethod
    def expect_column_values_to_match_like_pattern(column, like_pattern):
        return ExpectationUtil._build(
            "expect_column_values_to_match_like_pattern",
            column=column,
            like_pattern=like_pattern,
        )

    @staticmethod
    def expect_column_values_to_not_match_like_pattern(column, like_pattern):
        return ExpectationUtil._build(
            "expect_column_values_to_not_match_like_pattern",
            column=column,
            like_pattern=like_pattern,
        )

    @staticmethod
    def expect_column_values_to_match_like_pattern_list(column, like_pattern_list):
        return ExpectationUtil._build(
            "expect_column_values_to_match_like_pattern_list",
            column=column,
            like_pattern_list=like_pattern_list,
        )

    @staticmethod
    def expect_column_values_to_not_match_like_pattern_list(column, like_pattern_list):
        return ExpectationUtil._build(
            "expect_column_values_to_not_match_like_pattern_list",
            column=column,
            like_pattern_list=like_pattern_list,
        )

    # ========= Date / time / JSON expectations =========

    @staticmethod
    def expect_column_values_to_match_strftime_format(column, strftime_format):
        return ExpectationUtil._build(
            "expect_column_values_to_match_strftime_format",
            column=column,
            strftime_format=strftime_format,
        )

    @staticmethod
    def expect_column_values_to_be_dateutil_parseable(column):
        return ExpectationUtil._build(
            "expect_column_values_to_be_dateutil_parseable",
            column=column,
        )

    @staticmethod
    def expect_column_values_to_match_json_schema(column, json_schema):
        return ExpectationUtil._build(
            "expect_column_values_to_match_json_schema",
            column=column,
            json_schema=json_schema,
        )
