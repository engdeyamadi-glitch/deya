from great_expectations.datasource.fluent import SQLDatasource

class DataSource:
    """
    Simple wrapper around a SQL connection for Great Expectations Fluent API.

    - Builds a SQLAlchemy connection string from the given DB info.
    - Registers a Fluent SQLDatasource on a GX DataContext (Ephemeral or File).
    """

    def __init__(self, username, password, ipAddress, port, dataSchema, dataBaseType):
        """
        dataBaseType is your Enum (DataBaseType) whose .value is like:
          - 'mysql+pymysql'
          - 'postgresql+psycopg2'
        """
        self.username = username
        self.password = password
        self.ipAddress = ipAddress
        self.port = port
        self.dataSchema = dataSchema
        self.dataBaseType = dataBaseType

        # Example: mysql+pymysql://user:pass@127.0.0.1:3306/my_db
        self.connectionString = (
            f"{self.dataBaseType.value}://"
            f"{self.username}:{self.password}@"
            f"{self.ipAddress}:{self.port}/"
            f"{self.dataSchema}"
        )

    # ------------------------------------------------------------------
    # Legacy-style config (kept only for backward compatibility).
    # You don't need this in the new Fluent flow, but it's harmless to keep.
    # ------------------------------------------------------------------
    def getMySQLDataCourceConfig(self):
        """
        Legacy V2-style config dictionary.
        Not used anymore by the new Fluent code, but kept so old code
        doesn’t break if it still calls this method.
        """
        datasource_config = {
            "name": "my_mysql_datasource",
            "class_name": "Datasource",
            "execution_engine": {
                "class_name": "SqlAlchemyExecutionEngine",
                "connection_string": self.connectionString,
            },
            "data_connectors": {
                "default_runtime_data_connector_name": {
                    "class_name": "RuntimeDataConnector",
                    "batch_identifiers": ["default_identifier_name"],
                },
                "default_inferred_data_connector_name": {
                    "class_name": "InferredAssetSqlDataConnector",
                    "include_schema_name": True,
                },
            },
        }
        return datasource_config

    # ------------------------------------------------------------------
    # New Fluent method used by your updated DataQualityCheck.py
    # ------------------------------------------------------------------
    def register_sql_datasource(self, context, name: str = "my_sql_datasource") -> SQLDatasource:
        """
        Create a Fluent SQLDatasource and register it on the given context.

        This works with EphemeralDataContext and FileDataContext in GE 1.2.2.

        Usage:
            gx_datasource = dataSource.register_sql_datasource(
                context=context,
                name="MySqlDB-DataSource"
            )
        """
        datasource = SQLDatasource(
            name=name,
            connection_string=self.connectionString,
        )

        # IMPORTANT: EphemeralDataContext has `add_datasource`, but no `.sources`.
        # So we register the fluent datasource like this:
        context.add_datasource(datasource=datasource)

        return datasource
