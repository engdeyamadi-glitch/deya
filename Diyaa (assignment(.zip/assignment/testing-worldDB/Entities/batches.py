from great_expectations.core.batch import RuntimeBatchRequest

class Batch:
    
    @staticmethod
    def get_batch(datasource, schema_name: str, table_name: str, condition: str = ""):
        """
        Build a Fluent BatchRequest using a SQL query asset.

        - datasource: the Fluent SQLDatasource returned by DataSource.register_sql_datasource(...)
        - schema_name: DB/schema name (e.g., 'sakila')
        - table_name: table name (e.g., 'film')
        - condition: optional WHERE / ORDER BY etc, e.g. "WHERE active = 1"
        """

        condition = (condition or "").strip()
        query = f"SELECT * FROM {schema_name}.{table_name}"
        if condition:
            query = f"{query} {condition}"

        asset_name = f"{schema_name}_{table_name}_query_asset"

        # Try to reuse the asset if it already exists
        try:
            asset = datasource.get_asset(asset_name)
        except Exception:
            asset = datasource.add_query_asset(name=asset_name, query=query)

        batch_request = asset.build_batch_request()
        return batch_request
